import { requireSession } from '@/lib/auth';
import { eventFull, eventShort, eventTime, zoneLabel } from '@/lib/eventTime';
import { createClient } from '@/lib/supabase/server';
import { isPaid } from '@/lib/tiers';
import { mapsUrl } from '@/lib/matching';
import { TAG_CATEGORIES } from '@/lib/types';
import { PostForm } from './PostForm';
import { Avatar } from '@/components/Avatar';
import { RichText } from '@/components/RichText';
import { blockedIdsFor } from '@/lib/blocks';
import { MemberBadge } from '@/components/MemberBadge';
import { PostActions } from './PostActions';
import { PostEngagement } from './PostEngagement';

export const dynamic = 'force-dynamic';

export const metadata = { title: 'Dashboard — Project Connect' };

export default async function DashboardPage() {
  const { user, profile, subscription } = await requireSession();
  const supabase = createClient();
  const paid = isPaid(subscription.tier, subscription.status, subscription.current_period_end);

  const [{ data: seats }, { data: tags }, { data: posts, error: postsError }] = await Promise.all([
    supabase.from('event_seats')
      .select('id,status,table_no,events(id,title,kind,starts_at,seat_cap,status,status_note,venues(name,address))')
      .eq('profile_id', user.id).neq('status', 'cancelled')
      .order('created_at', { ascending: false }),
    supabase.from('profile_tags').select('category').eq('profile_id', user.id),
    supabase.from('posts')
      .select('id,body,image_url,created_at,author_id,chapter_id')
      .order('created_at', { ascending: false }).limit(50),
  ]);

  // Blocking is mutual invisibility: their posts leave your feed, and yours
  // leave theirs, so neither can reach the other's content at all.
  const hiddenIds = await blockedIdsFor(user.id);
  const visiblePosts = (posts ?? []).filter((p: any) =>
    !p.author_id || !hiddenIds.has(p.author_id));

  const postIds = visiblePosts.map((p: any) => p.id);
  const authorIds = Array.from(new Set(visiblePosts.map((p: any) => p.author_id)));

  const safe = async (fn: () => any): Promise<any[]> => {
    try {
      const res = await fn();
      return res?.data ?? [];
    } catch {
      return [];
    }
  };

  const PERSON = 'id,full_name,photo_url,role_level,city,role,speaker_approved';

  const [authors, likes, comments] = await Promise.all([
    authorIds.length
      ? safe(() => supabase.from('profiles').select(PERSON).in('id', authorIds))
      : Promise.resolve([] as any[]),
    postIds.length
      ? safe(() => supabase.from('post_likes').select('post_id,profile_id,reaction,created_at').in('post_id', postIds))
      : Promise.resolve([] as any[]),
    postIds.length
      ? safe(() => supabase.from('post_comments').select('id,post_id,body,created_at,author_id').in('post_id', postIds))
      : Promise.resolve([] as any[]),
  ]);

  const authorMap = new Map<string, any>((authors ?? []).map((a: any) => [a.id, a]));
  // always trust the session for your own rows, even if the lookup is blocked
  authorMap.set(user.id, {
    id: user.id,
    full_name: profile.full_name ?? authorMap.get(user.id)?.full_name ?? null,
    photo_url: profile.photo_url ?? authorMap.get(user.id)?.photo_url ?? null,
    role_level: profile.role_level ?? authorMap.get(user.id)?.role_level ?? null,
    city: profile.city ?? authorMap.get(user.id)?.city ?? null,
    role: profile.role,
    speaker_approved: profile.speaker_approved,
  });

  const planIds = [...authorMap.keys()];
  const plans = planIds.length
    ? await safe(() => supabase.from('subscriptions').select('profile_id,tier,status').in('profile_id', planIds))
    : [];
  const planOf = new Map<string, any>((plans ?? []).map((s: any) => [s.profile_id, s]));

  const visibleComments = (comments ?? []).filter((c: any) =>
    !c.author_id || !hiddenIds.has(c.author_id));

  const commenterIds = Array.from(new Set([
    ...visibleComments.map((c: any) => c.author_id),
    ...(likes ?? []).map((l: any) => l.profile_id),
  ])).filter((id: any) => id && !authorMap.has(id));
  if (commenterIds.length) {
    const extra = await safe(() => supabase.from('profiles').select(PERSON).in('id', commenterIds));
    for (const a of extra) authorMap.set(a.id, a);
  }

  // A speaker holds no seat at their own talk, so hosted events were invisible
  // here and the next event was whichever one they had a seat at.
  const { data: hosted } = await supabase
    .from('events')
    .select('id,title,kind,starts_at,seat_cap,status,status_note,venues(name,address)')
    .or('host_id.eq.' + user.id + ',created_by.eq.' + user.id)
    .neq('status', 'cancelled')
    .gte('starts_at', new Date().toISOString())
    .order('starts_at');

  const seatEventIds = new Set((seats ?? []).map((s: any) => s.events?.id).filter(Boolean));

  const hostedRows: any[] = (hosted ?? [])
    .filter((e: any) => !seatEventIds.has(e.id))
    .map((e: any) => ({
      id: 'host-' + e.id,
      status: e.kind === 'talk' ? 'speaking' : 'hosting',
      table_no: null,
      events: e,
    }));

  const allRows: any[] = [...(seats ?? []), ...hostedRows];

  const upcoming: any[] = allRows
    .filter((s: any) => s.events && new Date(s.events.starts_at) > new Date())
    .sort((a: any, b: any) => +new Date(a.events.starts_at) - +new Date(b.events.starts_at));
  const next = upcoming[0];

  const filledGroups = new Set((tags ?? []).map((t: any) => t.category)).size;
  const strength = Math.round((filledGroups / TAG_CATEGORIES.length) * 100);

  return (
    <main className="wrap">
      <div style={{
        display: 'flex', gap: 18, alignItems: 'center',
        justifyContent: 'space-between', flexWrap: 'wrap',
      }}>
        <h1>Dashboard</h1>

        <a href={'/members/' + user.id}
          style={{ display: 'flex', gap: 16, alignItems: 'center', color: 'inherit', textDecoration: 'none' }}>
          <Avatar src={profile.photo_url} name={profile.full_name} email={profile.email} size={104} />
          <div style={{ minWidth: 0 }}>
            <p style={{ margin: 0, fontSize: 21, fontWeight: 600 }}>
              {profile.full_name || 'Your profile'}
            </p>
            <p className="mute" style={{ margin: '4px 0 0', fontSize: 15 }}>
              {[profile.role_level, profile.city].filter(Boolean).join(' · ')}
            </p>
          </div>
        </a>
      </div>

      <div className="grid" style={{ gridTemplateColumns: 'minmax(0,5fr) minmax(0,3fr) minmax(0,4fr)', marginTop: 26 }}>
        <div className="surf" style={{ padding: 24, background: 'linear-gradient(160deg,var(--gold-100),#fff)' }}>
          <div className="row" style={{ gap: 8, justifyContent: 'space-between' }}>
            <p className="eyebrow" style={{ margin: 0 }}>Your next event</p>
            {next?.events && (
              <span className="pill" style={{
                background: '#fff', border: '1px solid var(--gold-200)', color: 'var(--gold-700)',
              }}>
                {next.status === 'speaking' ? 'You are speaking'
                  : next.status === 'hosting' ? 'You are hosting'
                    : next.events.kind === 'talk' ? 'Speaker Series' : 'Coffee meetup'}
              </span>
            )}
          </div>
          {next ? (
            <>
              <h2 style={{ marginTop: 10, fontSize: 24 }}>
                <a href={'/events/' + next.events.id} className="evlink"
                  style={{ color: 'inherit' }}>
                  {next.events.title}
                </a>
              </h2>
              <p className="mute" style={{ marginTop: 8 }}>
                {eventFull(next.events.starts_at, profile.city)}
              </p>
              <p className="mute">{next.events.venues?.name}{next.table_no ? ' · Table ' + next.table_no : ''}</p>
              <div className="row" style={{ marginTop: 18 }}>
                {next.events.venues?.address && (
                  <a className="btn btn-out" target="_blank" rel="noopener noreferrer"
                    href={mapsUrl(next.events.venues.address)}>Directions</a>
                )}
                <a className="btn btn-gold" href="/events">See all events</a>
              </div>
            </>
          ) : (
            <>
              <p style={{ marginTop: 10 }}>Nothing booked yet.</p>
              <a className="btn btn-gold" href="/events" style={{ marginTop: 14 }}>Find an event</a>
            </>
          )}
        </div>

        <div className="surf" style={{ padding: 24 }}>
          <p className="eyebrow">Profile strength</p>
          <p style={{ fontFamily: 'var(--font-heading)', fontSize: 40, margin: '10px 0 0' }}>{strength}%</p>
          <div style={{ height: 8, borderRadius: 99, background: 'var(--gold-100)', marginTop: 12, overflow: 'hidden' }}>
            <span style={{ display: 'block', width: strength + '%', height: '100%',
              background: 'linear-gradient(90deg,var(--gold),var(--gold-700))' }} />
          </div>
          <p className="small mute" style={{ marginTop: 10 }}>
            {strength < 100 ? 'Fill in more groups under Your experience to sharpen matching.' : 'Fully mapped.'}
          </p>
          <a className="btn btn-out" href="/profile" style={{ marginTop: 14, width: '100%' }}>Edit profile</a>
        </div>

        <div className="surf" style={{ padding: 24 }}>
          <p className="eyebrow">My RSVPs</p>
          <div className="grid" style={{ gap: 10, marginTop: 14 }}>
            {allRows
              .filter((s: any) => s.events)
              .sort((a: any, b: any) => +new Date(a.events.starts_at) - +new Date(b.events.starts_at))
              .slice(0, 5).map((s: any) => (
              <a key={s.id} href={s.events?.id ? '/events/' + s.events.id : '#'}
                className="row evrow"
                style={{
                  border: '1px solid var(--line)', borderRadius: 12, padding: '10px 12px',
                  color: 'inherit', textDecoration: 'none',
                }}>
                <div style={{ flex: 1, minWidth: 0 }}>
                  <strong style={{ fontSize: 15 }}>{s.events?.title}</strong>
                  <p className="small mute" style={{ margin: '2px 0 0' }}>
                    {s.events?.kind === 'talk' ? 'Speaker Series' : 'Coffee meetup'}
                    {s.events
                      ? ' · ' + eventShort(s.events.starts_at, profile.city)
                        + ' · ' + eventTime(s.events.starts_at, profile.city)
                        + ' ' + zoneLabel(profile.city, new Date(s.events.starts_at))
                      : ''}
                  </p>
                </div>
                <span className={'pill ' + (
                  s.events?.status === 'postponed' ? 'pill-off'
                    : s.status === 'confirmed' || s.status === 'speaking' || s.status === 'hosting'
                      ? 'pill-ok'
                      : s.status === 'waitlist' ? 'pill-off' : 'pill-wait')}>
                  {s.events?.status === 'postponed' ? 'postponed' : s.status}
                </span>
              </a>
            ))}
            {!allRows.length && <p className="small mute">No RSVPs yet.</p>}
          </div>
        </div>
      </div>

      <h2 style={{ marginTop: 34 }}>Feed</h2>
      <div className="grid" style={{ gridTemplateColumns: 'minmax(0,7fr) minmax(0,4fr)', marginTop: 16, alignItems: 'start' }}>
        <div className="grid" style={{ gap: 14 }}>
          <PostForm />
          {visiblePosts.map((p: any) => (
            <article key={p.id} id={'post-' + p.id} className="surf lift" style={{ padding: 24 }}>
              <header className="posthead">
                <a href={'/members/' + p.author_id} aria-label="View profile" style={{ flex: 'none', lineHeight: 0 }}>
                  <Avatar src={authorMap.get(p.author_id)?.photo_url}
                    name={authorMap.get(p.author_id)?.full_name} size={52} />
                </a>

                <div style={{ minWidth: 0, flex: 1 }}>
                  <div style={{ display: 'flex', alignItems: 'center', gap: 8, flexWrap: 'wrap' }}>
                    {authorMap.get(p.author_id) ? (
                      <a href={'/members/' + p.author_id} className="postname"
                        style={{ color: 'var(--ink)', textDecoration: 'none' }}>
                        {authorMap.get(p.author_id)?.full_name ?? 'Member'}
                      </a>
                    ) : (
                      <span className="postname mute">Former member</span>
                    )}
                    <MemberBadge
                      role={authorMap.get(p.author_id)?.role}
                      speakerApproved={authorMap.get(p.author_id)?.speaker_approved
                        || authorMap.get(p.author_id)?.role === 'speaker'}
                      tier={planOf.get(p.author_id)?.tier}
                      status={planOf.get(p.author_id)?.status} />
                  </div>

                  {authorMap.get(p.author_id)?.role_level && (
                    <p className="mute postmeta">{authorMap.get(p.author_id).role_level}</p>
                  )}
                </div>

                <div className="postaside">
                  {authorMap.get(p.author_id)?.city && (
                    <span className="pill pill-wait" style={{ whiteSpace: 'nowrap' }}>
                      {authorMap.get(p.author_id).city}
                    </span>
                  )}
                  <span className="mute postdate">
                    {new Date(p.created_at).toLocaleDateString('en-CA', { month: 'short', day: 'numeric' })}
                  </span>
                </div>
              </header>
              {p.body && (
                <p style={{ fontSize: 16.5, lineHeight: 1.7, margin: '18px 0 0' }}>
                  <RichText text={p.body} />
                </p>
              )}
              {p.image_url && (
                <a href={p.image_url} target="_blank" rel="noopener noreferrer"
                  style={{
                    display: 'block', marginTop: 16, borderRadius: 14,
                    overflow: 'hidden', border: '1px solid var(--line)',
                    background: 'var(--gold-100)',
                  }}>
                  <img src={p.image_url} alt="" loading="lazy"
                    style={{
                      display: 'block', width: '100%', height: 'auto',
                      maxHeight: 620, objectFit: 'contain',
                    }} />
                </a>
              )}
              <footer className="row" style={{ gap: 6, marginTop: 18, paddingTop: 14, borderTop: '1px solid var(--line)' }}>
                <span style={{ marginRight: 'auto' }} />
                {(p.author_id === user.id || profile.role === 'admin') && <PostActions postId={p.id} />}
              </footer>
              <PostEngagement
                postId={p.id}
                likeCount={(likes ?? []).filter((l: any) => l.post_id === p.id).length}
                liked={(likes ?? []).some((l: any) => l.post_id === p.id && l.profile_id === user.id)}
                reactions={(likes ?? [])
                  .filter((l: any) => l.post_id === p.id)
                  .map((l: any) => l.reaction ?? 'like')}
                myReaction={(likes ?? [])
                  .find((l: any) => l.post_id === p.id && l.profile_id === user.id)?.reaction ?? null}
                reactors={(likes ?? [])
                  .filter((l: any) => l.post_id === p.id && !hiddenIds.has(l.profile_id))
                  .map((l: any) => ({
                    id: l.profile_id,
                    reaction: l.reaction ?? 'like',
                    name: authorMap.get(l.profile_id)?.full_name ?? 'Member',
                    photo: authorMap.get(l.profile_id)?.photo_url ?? null,
                    role_level: authorMap.get(l.profile_id)?.role_level ?? null,
                  }))}
                comments={visibleComments
                  .filter((c: any) => c.post_id === p.id)
                  .sort((a: any, b: any) => +new Date(a.created_at) - +new Date(b.created_at))
                  .map((c: any) => ({ ...c, commenter: authorMap.get(c.author_id) }))}
                userId={user.id}
                isAdmin={profile.role === 'admin'}
              />
            </article>
          ))}
          {postsError && (
            <div className="surf" style={{ padding: 18, borderColor: 'var(--err)' }}>
              <strong style={{ color: 'var(--err)' }}>Feed could not load</strong>
              <p className="small mute" style={{ marginTop: 6, whiteSpace: 'pre-wrap' }}>{postsError.message}</p>
            </div>
          )}
          {!postsError && !visiblePosts.length && <p className="mute">No posts yet. Write the first one above.</p>}
        </div>

        <aside className="surf" style={{ padding: 22, position: 'sticky', top: 84 }}>
          <p className="eyebrow">Your chapter</p>
          <h3 style={{ marginTop: 10 }}>{profile.city ?? 'Pick a chapter'}</h3>
          <p className="small mute" style={{ marginTop: 8 }}>
            {paid ? 'Unlimited events and Speaker Series talks.' : 'Free covers one event per cycle. Talks need a paid plan.'}
          </p>
          <div className="grid" style={{ gap: 8, marginTop: 16 }}>
            <a className="btn btn-gold" href="/events">See events</a>
          </div>
        </aside>
      </div>
    </main>
  );
}

import { notFound } from 'next/navigation';
import { eventFull } from '@/lib/eventTime';
import { getSession } from '@/lib/auth';
import { createClient, createAdminClient } from '@/lib/supabase/server';
import { isPaid } from '@/lib/tiers';
import { mapsUrl } from '@/lib/matching';
import { RsvpButton } from '@/components/RsvpButton';
import { MatchAttendeesButton } from '@/components/MatchAttendeesButton';
import { Avatar } from '@/components/Avatar';
import { RichText } from '@/components/RichText';
import { VenuePhoto } from '@/components/VenuePhoto';
import { MemberBadge } from '@/components/MemberBadge';
import { JoinPanel } from '@/components/JoinPanel';
import { EditEvent } from '@/components/EditEvent';
import { LiveSeats } from '@/components/LiveSeats';
import { VenueNotice } from '@/components/VenueNotice';
import { describeMix } from '@/lib/matching';

export const dynamic = 'force-dynamic';

export default async function EventPage({ params }: { params: { id: string } }) {
  const session = await getSession();
  const supabase = createClient();

  const { data: e } = await supabase
    .from('events')
    .select('id,title,kind,description,starts_at,duration_min,seat_cap,status,status_note,original_starts_at,host_id,created_by,chapter_id,venue_id,format,meeting_url,meeting_note,chapters(city),venues(name,address,notes,photo_url)')
    .eq('id', params.id).maybeSingle();
  if (!e) notFound();

  // People sharing a table are meant to see each other, but the RLS policy on
  // event_seats only exposes your own row — read the roster past it.
  const db = createAdminClient();

  const { data: venueOptions } = await db.from('venues')
    .select('id,name,chapter_id').eq('chapter_id', e.chapter_id).eq('active', true).order('name');

  const { data: seats } = await db
    .from('event_seats').select('id,status,profile_id,table_no,created_at')
    .eq('event_id', params.id).order('created_at');

  const attendeeIds = (seats ?? [])
    .filter((s) => s.status === 'confirmed' || s.status === 'waitlist')
    .map((s) => s.profile_id);

  const [{ data: people }, { data: domainTags }] = await Promise.all([
    attendeeIds.length
      ? db.from('profiles')
          .select('id,full_name,photo_url,role_level,city,employer,role,speaker_approved')
          .in('id', attendeeIds)
      : Promise.resolve({ data: [] as any[] }),
    attendeeIds.length
      ? db.from('profile_tags')
          .select('profile_id,value').eq('category', 'domain').in('profile_id', attendeeIds)
      : Promise.resolve({ data: [] as any[] }),
  ]);

  const personById = new Map((people ?? []).map((x: any) => [x.id, x]));

  const { data: attendeePlans } = attendeeIds.length
    ? await db.from('subscriptions').select('profile_id,tier,status').in('profile_id', attendeeIds)
    : { data: [] as any[] };
  const planOf = new Map((attendeePlans ?? []).map((s: any) => [s.profile_id, s]));

  // The host may predate having a seat, so fetch them regardless
  const hostId = e.host_id ?? e.created_by;
  if (hostId && !personById.has(hostId)) {
    const { data: host } = await db.from('profiles')
      .select('id,full_name,photo_url,role_level,city,employer,role,speaker_approved,intro')
      .eq('id', hostId).maybeSingle();
    if (host) personById.set(host.id, host);
  }
  const domainsOf = new Map<string, string[]>();
  for (const t of domainTags ?? []) {
    if (!domainsOf.has(t.profile_id)) domainsOf.set(t.profile_id, []);
    domainsOf.get(t.profile_id)!.push(t.value);
  }

  // On a talk the speaker presents rather than attends, so they sit outside
  // the audience count. On a meetup the host is one of the people at the table.
  const speakerId = e.kind === 'talk' ? (e.host_id ?? e.created_by) : null;
  const isSpeakerSeat = (pid: string) => speakerId !== null && pid === speakerId;

  const myLiveSeat = session
    ? (seats ?? []).find((s: any) => s.profile_id === session.user.id
        && (s.status === 'confirmed' || s.status === 'waitlist'))
    : null;

  const going = (seats ?? [])
    .filter((s) => s.status === 'confirmed' && !isSpeakerSeat(s.profile_id));
  const waitlist = (seats ?? [])
    .filter((s) => s.status === 'waitlist' && !isSpeakerSeat(s.profile_id));

  const mixDomains = [...new Set(going.flatMap((s) => domainsOf.get(s.profile_id) ?? []))];
  const mixLevels = [...new Set(going
    .map((s) => personById.get(s.profile_id)?.role_level)
    .filter(Boolean))] as string[];

  const notice = e.venue_id
    ? await db.from('venue_notifications')
        .select('status,to_email').eq('event_id', e.id)
        .order('created_at', { ascending: false }).limit(1)
        .then((r) => r.data?.[0] ?? null)
        .catch(() => null)
    : null;

  const venueContact = e.venue_id
    ? await db.from('venues').select('contact_email,notify').eq('id', e.venue_id).limit(1)
        .then((r) => r.data?.[0] ?? null)
        .catch(() => null)
    : null;

  // Hosting is not an RSVP decision: a speaker presents to their own room, and
  // a meetup host is already at their own table. Neither gets a seat button.
  const isOwnEvent = !!session && (
    e.host_id === session.user.id || e.created_by === session.user.id
  );

  const canSeat = !!session && (
    session.profile.role === 'admin'
    || e.created_by === session.user.id
    || e.host_id === session.user.id
    || e.created_by === session.user.id
    || (session.profile.lead_chapter_id && session.profile.lead_chapter_id === e.chapter_id)
  );


  const confirmed = going.length;
  const mine = session ? (seats ?? []).find((s) => s.profile_id === session.user.id) : null;
  const paid = session ? isPaid(session.subscription.tier, session.subscription.status, session.subscription.current_period_end) : false;
  const d = new Date(e.starts_at);
  // PostgREST returns an embed as an object or an array depending on the
  // relationship it infers — and an empty array when there is no venue at all.
  const venueRaw = (e as any).venues;
  const venue = (Array.isArray(venueRaw) ? venueRaw[0] : venueRaw) ?? null;
  const chapterRaw = (e as any).chapters;
  const city = (Array.isArray(chapterRaw) ? chapterRaw[0] : chapterRaw)?.city;

  // A full address geocodes far better than a bare street line
  const mapQuery = venue?.address
    ? (venue.address.toLowerCase().includes(String(city ?? '').toLowerCase())
        ? venue.address
        : venue.address + ', ' + city)
    : null;

  const key = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;

  const finalSrc = mapQuery
    ? (key
        ? 'https://www.google.com/maps/embed/v1/place?key=' + key
            + '&q=' + encodeURIComponent(mapQuery) + '&zoom=16'
        : 'https://maps.google.com/maps?q=' + encodeURIComponent(mapQuery)
            + '&z=16&hl=en&output=embed')
    : null;

  return (
    <main className="wrap" style={{ maxWidth: 860 }}>
      <LiveSeats eventId={e.id} />
      {venue?.photo_url && (
        <div className="surf venuebrand" style={{ padding: 0, overflow: 'hidden', marginBottom: 18 }}>
          <VenuePhoto photoUrl={venue.photo_url} address={mapQuery ?? null}
            name={venue.name} height={140} />
          <div style={{ padding: '18px 22px', display: 'grid', alignContent: 'center', gap: 3 }}>
            <span className="eyebrow" style={{ margin: 0 }}>Hosted at</span>
            <strong style={{ fontSize: 19, lineHeight: 1.25 }}>{venue.name}</strong>
            {venue.address && <span className="mute small">{venue.address}</span>}
          </div>
        </div>
      )}

      <p className="eyebrow">{city} · {e.kind === 'talk' ? 'Speaker Series' : 'Meetup'}</p>
      <h1 style={{ marginTop: 12 }}>{e.title}</h1>
      <p className="mute" style={{ marginTop: 12, fontSize: 17 }}>
        {eventFull(e.starts_at, (e.chapters as any)?.city)} · {e.duration_min} minutes
      </p>

      {(e.status === 'postponed' || e.status === 'cancelled' || e.original_starts_at) && (
        <div style={{
          marginTop: 16, padding: '16px 20px', borderRadius: 14,
          border: '1px solid ' + (e.status === 'cancelled' ? 'rgba(180,35,24,.3)' : 'var(--gold-200)'),
          background: e.status === 'cancelled' ? '#fff6f5' : 'var(--gold-100)',
        }}>
          <strong style={{ color: e.status === 'cancelled' ? 'var(--err)' : 'var(--gold-700)' }}>
            {e.status === 'cancelled' ? 'This event was cancelled'
              : e.status === 'postponed' ? 'Postponed — a new date is coming'
                : 'This event was moved'}
          </strong>
          {e.original_starts_at && e.status !== 'cancelled' && (
            <p className="mute" style={{ margin: '6px 0 0', fontSize: 14.5 }}>
              Originally {eventFull(e.original_starts_at, (e.chapters as any)?.city)}
            </p>
          )}
          {e.status_note && (
            <p style={{ margin: '8px 0 0', fontSize: 15, lineHeight: 1.6 }}>{e.status_note}</p>
          )}
        </div>
      )}

      <div className="surf" style={{ padding: 24, marginTop: 24 }}>
        {e.description && (
          <p style={{ marginTop: 0, lineHeight: 1.65 }}>
            <RichText text={e.description} />
          </p>
        )}
        <dl className="grid g2" style={{ marginTop: 8 }}>
          <div>
            <dt className="eyebrow">Venue</dt>
            <dd style={{ margin: '6px 0 0' }}>
              {e.format === 'online' ? 'Online' : (venue?.name ?? 'To be confirmed')}
              {venue?.address && <><br /><span className="mute small">{venue.address}</span></>}
              {venue?.notes && <><br /><span className="mute small">{venue.notes}</span></>}
            </dd>
          </div>
          <div>
            <dt className="eyebrow">Seats</dt>
            <dd style={{ margin: '6px 0 0' }}>{confirmed} confirmed of {e.seat_cap}</dd>
          </div>
          {personById.get(hostId ?? '')?.full_name && (
            <div>
              <dt className="eyebrow">Host</dt>
              <dd style={{ margin: '8px 0 0' }}>
                <a href={'/members/' + hostId}
                  style={{
                    display: 'inline-flex', gap: 12, alignItems: 'center',
                    textDecoration: 'none', color: 'inherit',
                  }}>
                  <Avatar src={personById.get(hostId ?? '')?.photo_url}
                    name={personById.get(hostId ?? '')?.full_name}
                    size={52} />
                  <span>
                    <span style={{ display: 'block', fontWeight: 600, fontSize: 16.5 }}>
                      {personById.get(hostId ?? '')?.full_name}
                    </span>
                    <span className="mute small">
                      {[personById.get(hostId ?? '')?.role_level, personById.get(hostId ?? '')?.intro]
                        .filter(Boolean).join(' · ')}
                    </span>
                  </span>
                </a>
              </dd>
            </div>
          )}
        </dl>

        {canSeat && venue?.name && (
          <VenueNotice eventId={e.id} venueName={venue.name}
            status={notice?.status ?? null} toEmail={notice?.to_email ?? null}
            hasContact={!!venueContact?.contact_email} />
        )}

        {canSeat && going.length > 15 && (
          <div style={{
            marginTop: 20, padding: '16px 18px', borderRadius: 14,
            background: 'var(--gold-100)', border: '1px solid var(--gold-200)',
          }}>
            <p className="eyebrow" style={{ margin: 0 }}>Tables</p>
            <p className="mute small" style={{ margin: '6px 0 12px' }}>
              {going.length} people is more than one table. Split them into tables that spread
              domains and role levels, so nobody sits with only their own discipline.
            </p>
            <MatchAttendeesButton eventId={e.id} requestCount={going.length} seatCap={e.seat_cap} />
          </div>
        )}

        <div style={{ marginTop: 22, paddingTop: 20, borderTop: '1px solid var(--line)' }}>
          {!session ? (
            <a className="btn btn-gold" href="/signup">Join to RSVP</a>
          ) : isOwnEvent ? (
            <div>
              <span className="pill pill-ok" style={{ fontSize: 12 }}>
                {e.kind === 'talk' ? "You're speaking" : "You're hosting"}
              </span>
              <p className="hint">
                {e.kind === 'talk'
                  ? 'Your seat is at the front, so it is not counted against the audience. Manage the talk from your Speaker page.'
                  : 'Your seat is held as the host. To step back, cancel the meetup rather than your seat.'}
              </p>
            </div>
          ) : e.status === 'postponed' ? (
            <p className="mute" style={{ margin: 0 }}>Awaiting a new date — your seat is held.</p>
          ) : e.status === 'cancelled' ? (
            <p className="mute" style={{ margin: 0 }}>This event is off.</p>
          ) : e.kind === 'talk' && !paid ? (
            <div>
              <span className="mute small">Speaker Series is for paid members</span>
              <p className="hint">Free membership covers one meetup per cycle.</p>
            </div>
          ) : (
            <RsvpButton eventId={e.id} address={mapQuery}
              status={mine?.status ?? null} full={confirmed >= e.seat_cap} />
          )}
        </div>
      </div>

      {canSeat && (
        <div className="surf" style={{
          padding: 'clamp(18px,2.5vw,24px)', marginTop: 18,
          borderColor: 'var(--gold)', background: 'var(--gold-100)',
        }}>
          <p className="eyebrow" style={{ margin: 0 }}>You organise this event</p>
          <p className="mute small" style={{ margin: '6px 0 14px' }}>
            Change the title, description, date, seats or venue. Moving the date tells everyone
            holding a seat.
          </p>
          <EditEvent event={e} venues={venueOptions ?? []} city={(e.chapters as any)?.city} />
        </div>
      )}

      <JoinPanel format={(e as any).format} meetingUrl={(e as any).meeting_url}
        meetingNote={(e as any).meeting_note}
        canSee={!!myLiveSeat || canSeat} startsAt={e.starts_at} />

      <section className="surf" style={{ padding: 'clamp(22px,3vw,30px)', marginTop: 18 }}>
        {speakerId && personById.get(speakerId) && (
          <div style={{
            display: 'flex', gap: 14, alignItems: 'center', flexWrap: 'wrap',
            padding: '16px 18px', marginBottom: 22, borderRadius: 14,
            background: 'var(--gold-100)', border: '1px solid var(--gold-200)',
          }}>
            <a href={'/members/' + speakerId}
              style={{ display: 'flex', gap: 12, alignItems: 'center', textDecoration: 'none', color: 'inherit' }}>
              <Avatar src={personById.get(speakerId)?.photo_url}
                name={personById.get(speakerId)?.full_name} size={56} />
              <span>
                <span className="eyebrow" style={{ margin: 0 }}>Hosted by</span>
                <span style={{ display: 'block', fontWeight: 600, fontSize: 17, marginTop: 2 }}>
                  {personById.get(speakerId)?.full_name ?? 'Speaker'}
                </span>
                {personById.get(speakerId)?.role_level && (
                  <span className="mute small">{personById.get(speakerId)?.role_level}</span>
                )}
              </span>
            </a>
            <span className="mute small" style={{ marginLeft: 'auto', maxWidth: '30ch' }}>
              Presenting, so not counted against the seats below.
            </span>
          </div>
        )}

        <div className="row" style={{ justifyContent: 'space-between', alignItems: 'flex-end' }}>
          <div>
            <h2 style={{ fontSize: 26 }}>
              {e.kind === 'talk' ? 'Who\u2019s attending' : 'Who\u2019s coming'}
            </h2>
            {going.length > 0 && (
              <p className="mute small" style={{ margin: '6px 0 0' }}>
                {describeMix(mixDomains, mixLevels)}
              </p>
            )}
          </div>
          <span className="mute small">{going.length} of {e.seat_cap}</span>
        </div>

        {going.length === 0 ? (
          <p className="mute" style={{ marginTop: 16 }}>
            {e.kind === 'talk'
              ? 'No seats taken yet. Be the first in the room.'
              : 'Nobody yet. Take the first seat and others will be matched around you.'}
          </p>
        ) : (
          <div style={{
            display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
            gap: 12, marginTop: 20,
          }}>
            {going.map((s) => {
              const person = personById.get(s.profile_id);
              const domains = (domainsOf.get(s.profile_id) ?? []).slice(0, 2);
              return (
                <a key={s.id} href={'/members/' + s.profile_id}
                  style={{
                    display: 'flex', gap: 12, alignItems: 'flex-start',
                    padding: 14, borderRadius: 14, border: '1px solid var(--line)',
                    textDecoration: 'none', color: 'inherit', background: '#fff',
                  }}>
                  <Avatar src={person?.photo_url} name={person?.full_name} size={52} />
                  <div style={{ minWidth: 0 }}>
                    <span style={{ display: 'block', fontWeight: 600, fontSize: 16 }}>
                      {s.profile_id === hostId && (
                        <span className="pill pill-wait" style={{ marginLeft: 6, fontSize: 10 }}>Host</span>
                      )}
                      {s.profile_id !== hostId && (
                        <MemberBadge role={person?.role} speakerApproved={person?.speaker_approved}
                          tier={planOf.get(s.profile_id)?.tier}
                          status={planOf.get(s.profile_id)?.status} size="sm" />
                      )}
                    </span>
                    {person?.role_level && (
                      <span className="mute small" style={{ display: 'block', marginTop: 2 }}>
                        {person.role_level}
                      </span>
                    )}
                    {domains.length > 0 && (
                      <span className="mute small" style={{ display: 'block', marginTop: 4 }}>
                        {domains.join(' · ')}
                      </span>
                    )}
                    {s.table_no && (
                      <span className="mute small" style={{ display: 'block', marginTop: 4 }}>
                        Table {s.table_no}
                      </span>
                    )}
                  </div>
                </a>
              );
            })}
          </div>
        )}

        {waitlist.length > 0 && (
          <div style={{ marginTop: 22, paddingTop: 18, borderTop: '1px solid var(--line)' }}>
            <p className="eyebrow" style={{ margin: 0 }}>Waitlist · {waitlist.length}</p>
            <p className="mute small" style={{ margin: '6px 0 12px' }}>
              Promoted automatically, in order, whenever someone cancels.
            </p>
            <div className="row" style={{ gap: 10 }}>
              {waitlist.map((s, i) => {
                const person = personById.get(s.profile_id);
                return (
                  <a key={s.id} href={'/members/' + s.profile_id}
                    title={(person?.full_name ?? 'Member') + ' — position ' + (i + 1)}
                    style={{ display: 'flex', gap: 8, alignItems: 'center', textDecoration: 'none', color: 'inherit' }}>
                    <Avatar src={person?.photo_url} name={person?.full_name} size={34} />
                  </a>
                );
              })}
            </div>
          </div>
        )}
      </section>

      {(e as any).format !== 'online' && mapQuery && finalSrc && (
        <section className="surf" style={{ marginTop: 18, overflow: 'hidden' }}>
          <header className="row" style={{
            justifyContent: 'space-between', padding: '16px 20px',
            borderBottom: '1px solid var(--line)',
          }}>
            <div>
              <p className="eyebrow" style={{ margin: 0 }}>Getting there</p>
              <p style={{ margin: '4px 0 0', fontSize: 16 }}>{venue?.name}</p>
              <p className="mute small" style={{ margin: '2px 0 0' }}>{mapQuery}</p>
            </div>
            <div className="row" style={{ gap: 8 }}>
              <a className="btn btn-out" target="_blank" rel="noopener noreferrer"
                href={'https://www.google.com/maps/dir/?api=1&destination=' + encodeURIComponent(mapQuery!)}
                style={{ minHeight: 40, padding: '0 16px', fontSize: 14 }}>Directions</a>
              <a className="btn btn-gold" target="_blank" rel="noopener noreferrer"
                href={mapsUrl(mapQuery!)}
                style={{ minHeight: 40, padding: '0 16px', fontSize: 14 }}>Open in Maps</a>
            </div>
          </header>
          {finalSrc ? (
            <iframe
              title={'Map of ' + (venue?.name ?? 'the venue')}
              src={finalSrc}
              width="100%" height="340" loading="lazy"
              referrerPolicy="no-referrer-when-downgrade"
              style={{ border: 0, display: 'block' }} />
          ) : (
            <div style={{
              padding: 28, textAlign: 'center', background: 'var(--gold-100)',
            }}>
              <p className="mute" style={{ margin: 0 }}>
                Map preview unavailable — use Directions above to open it in Maps.
              </p>
            </div>
          )}
        </section>
      )}
    </main>
  );
}

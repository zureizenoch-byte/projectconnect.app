import { getSession } from '@/lib/auth';
import { createClient, createAdminClient } from '@/lib/supabase/server';
import { isPaid } from '@/lib/tiers';
import { RsvpButton } from '@/components/RsvpButton';
import { EventLifecycle } from '@/components/EventLifecycle';
import { EditEvent } from '@/components/EditEvent';
import { VenuePhoto } from '@/components/VenuePhoto';
import { RichText } from '@/components/RichText';
import { eventDate, eventTime, eventMonth, eventDay, zoneLabel } from '@/lib/eventTime';
import { detectPlatform, PLATFORM_LABEL } from '@/lib/meeting';

const platformLabel = (url?: string | null) => PLATFORM_LABEL[detectPlatform(url)];
import { LiveSeats } from '@/components/LiveSeats';
import { EventFilters } from '@/components/EventFilters';
import { canHostTalks } from '@/lib/permissions';

export const dynamic = 'force-dynamic';

export const metadata = { title: 'Events — Project Connect' };

const COLS = 'id,title,kind,description,starts_at,seat_cap,status,status_note,original_starts_at,host_id,created_by,chapters(city),venues(name,address,photo_url),event_seats(id,status,profile_id)';

export default async function EventsPage({ searchParams }: { searchParams: { city?: string; kind?: string } }) {
  const session = await getSession();
  const supabase = createClient();
  const paid = session ? isPaid(session.subscription.tier, session.subscription.status, session.subscription.current_period_end) : false;
  const isAdmin = session?.profile.role === 'admin';
  const canSchedule = !!session && (isAdmin
    || (session.profile.role === 'chapter_lead' && !!session.profile.lead_chapter_id));
  const canTalkHere = !!session && (isAdmin
    || (session.profile.role === 'speaker' && session.profile.speaker_approved));
  const canTalk = session ? canHostTalks(session.profile) : false;

  const query = isAdmin
    ? supabase.from('events').select(COLS).order('starts_at')
    : supabase.from('events').select(COLS)
        .in('status', ['published', 'postponed'])
        .gte('starts_at', new Date().toISOString())
        .order('starts_at');

  const { data: events } = await query;

  // event_seats is RLS-scoped to your own row, so counts read past it
  const db = createAdminClient();
  const eventIds = (events ?? []).map((e: any) => e.id);
  const { data: allSeats } = eventIds.length
    ? await db.from('event_seats').select('id,event_id,status,profile_id').in('event_id', eventIds)
    : { data: [] as any[] };
  const seatsOf = new Map<string, any[]>();
  for (const s of allSeats ?? []) {
    if (!seatsOf.has(s.event_id)) seatsOf.set(s.event_id, []);
    seatsOf.get(s.event_id)!.push(s);
  }
  const city = searchParams.city;
  const kind = searchParams.kind;
  const rows = (events ?? []).filter((e: any) =>
    (!city || e.chapters?.city === city)
    && (!kind
      || (kind === 'online' ? e.format === 'online' : e.kind === kind)));

  return (
    <main className="wrap">
      <LiveSeats />
      <div style={{
        display: 'flex', gap: 16, alignItems: 'flex-end',
        justifyContent: 'space-between', flexWrap: 'wrap',
      }}>
        <div>
          <h1>Events</h1>
          <p className="mute" style={{ marginTop: 10, maxWidth: '58ch' }}>
            Project Connect — real conversations, real people, real growth.
            Coffee meetups for project delivery professionals.
          </p>
        </div>
        <div className="row" style={{ gap: 10 }}>
          {session && canSchedule && (
            <a className="btn btn-gold" href="/events/new">Schedule a meetup</a>
          )}
          {session && canTalkHere && (
            <a className={canSchedule ? 'btn btn-out' : 'btn btn-gold'} href="/events/new?kind=talk">
              Schedule a talk
            </a>
          )}
        </div>
      </div>
      {isAdmin && (
        <p className="hint" style={{ marginTop: 8 }}>
          You're seeing every event, including drafts and past ones, with management controls on each.
        </p>
      )}

      <EventFilters city={city} kind={kind} count={rows.length} />

      <div style={{
        display: 'grid',
        gridTemplateColumns: 'repeat(auto-fill, minmax(380px, 1fr))',
        gap: 22, marginTop: 26, alignItems: 'stretch',
      }}>
        {rows.map((e: any) => {
          const seatRows = seatsOf.get(e.id) ?? e.event_seats ?? [];
          // a talk's speaker presents rather than attends, so is not a seat
          const presenterId = e.kind === 'talk' ? (e.host_id ?? e.created_by) : null;
          const confirmed = seatRows.filter((s: any) =>
            s.status === 'confirmed' && s.profile_id !== presenterId).length;
          const mine = session ? seatRows.find((s: any) => s.profile_id === session.user.id) : null;
          const full = confirmed >= e.seat_cap;
          const locked = e.kind === 'talk' && !paid;
          const d = new Date(e.starts_at);
          const cityName = e.chapters?.city ?? '';
          const address = e.venues?.address
            ? (e.venues.address.toLowerCase().includes(cityName.toLowerCase())
                ? e.venues.address
                : e.venues.address + ', ' + cityName)
            : null;
          const left = Math.max(0, e.seat_cap - confirmed);

          return (
            <article key={e.id} className="surf lift" style={{
              padding: 0, overflow: 'hidden', display: 'flex', flexDirection: 'column',
            }}>
              <a href={'/events/' + e.id} aria-label={e.title} style={{
                position: 'relative', display: 'block', textDecoration: 'none',
              }}>
                <VenuePhoto photoUrl={e.venues?.photo_url} address={address}
                  name={e.venues?.name ?? e.title} city={cityName} kind={e.kind} />

                <div style={{
                  position: 'absolute', top: 14, left: 14,
                  width: 58, height: 58, borderRadius: 12, display: 'grid', placeItems: 'center',
                  background: 'rgba(255,255,255,.94)', border: '1px solid var(--line)',
                  boxShadow: 'var(--sh)', color: 'var(--gold-700)',
                  fontFamily: 'var(--font-heading)',
                }}>
                  <span style={{ fontSize: 10.5, letterSpacing: '.1em', textTransform: 'uppercase' }}>
                    {eventMonth(e.starts_at, cityName)}
                  </span>
                  <span style={{ fontSize: 21, lineHeight: 1 }}>{eventDay(e.starts_at, cityName)}</span>
                </div>

                <div style={{
                  position: 'absolute', top: 14, right: 14, display: 'flex', gap: 6, flexWrap: 'wrap',
                  justifyContent: 'flex-end', maxWidth: '60%',
                }}>
                  <span className="pill" style={{
                    background: 'rgba(255,255,255,.94)', border: '1px solid var(--line)',
                    color: 'var(--gold-700)',
                  }}>
                    {e.kind === 'talk' ? 'Speaker Series' : 'Meetup'}
                  </span>
                  {e.format === 'online' && (
                    <span className="pill" style={{
                      background: 'rgba(255,255,255,.94)', border: '1px solid var(--line)',
                      color: 'var(--ink)',
                    }}>Online</span>
                  )}
                  {e.status === 'postponed' && (
                    <span className="pill" style={{
                      background: 'rgba(255,255,255,.94)', border: '1px solid var(--line)',
                      color: 'var(--mute)',
                    }}>Postponed</span>
                  )}
                  {isAdmin && e.status !== 'published' && e.status !== 'postponed' && (
                    <span className="pill" style={{
                      background: 'rgba(255,255,255,.94)', border: '1px solid var(--line)',
                      color: 'var(--gold-700)',
                    }}>{e.status}</span>
                  )}
                  {e.status === 'published' && e.status_note?.startsWith('Back on') ? (
                    <span className="pill" style={{
                      background: '#e8f6ed', border: '1px solid #bde5cb', color: 'var(--ok)',
                    }}>Back on</span>
                  ) : e.status === 'published' && e.original_starts_at ? (
                    <span className="pill" style={{
                      background: 'rgba(255,255,255,.94)', border: '1px solid var(--line)',
                      color: 'var(--gold-700)',
                    }}>New date</span>
                  ) : null}
                </div>
              </a>

              <div style={{ padding: 22, display: 'flex', flexDirection: 'column', gap: 12, flex: 1 }}>
                <div>
                  <p className="eyebrow" style={{ margin: 0 }}>
                    {eventDate(e.starts_at, cityName)}
                    {' · '}
                    {eventTime(e.starts_at, cityName)} {zoneLabel(cityName, new Date(e.starts_at))}
                  </p>
                  <p className="mute small" style={{ margin: '4px 0 0' }}>{cityName}</p>
                  <h3 style={{ marginTop: 8, fontSize: 24, lineHeight: 1.12 }}>
                    <a href={'/events/' + e.id} style={{ textDecoration: 'none', color: 'var(--ink)' }}>
                      {e.title}
                    </a>
                  </h3>
                  {e.format === 'online' ? (
                    <p className="mute small" style={{ marginTop: 6 }}>
                      {platformLabel(e.meeting_url)} · link shared when you take a seat
                    </p>
                  ) : e.venues?.name ? (
                    <p className="mute small" style={{ marginTop: 6, lineHeight: 1.5 }}>
                      <strong style={{ fontWeight: 600, color: 'var(--ink)' }}>{e.venues.name}</strong>
                      {e.venues.address && <><br />{e.venues.address}</>}
                    </p>
                  ) : null}
                </div>

                {e.status_note && (
                  <p style={{
                    margin: 0, padding: '8px 12px', borderRadius: 10, fontSize: 14,
                    background: 'var(--gold-100)', border: '1px solid var(--gold-200)',
                    color: 'var(--gold-700)',
                  }}>{e.status_note}</p>
                )}

                {e.description && (
                  <p className="mute" style={{
                    margin: 0, fontSize: 15, lineHeight: 1.6, whiteSpace: 'pre-line',
                    display: '-webkit-box', WebkitLineClamp: 3, WebkitBoxOrient: 'vertical',
                    overflow: 'hidden',
                  }}><RichText text={e.description} /></p>
                )}

                <div style={{
                  marginTop: 'auto', paddingTop: 16, borderTop: '1px solid var(--line)',
                  display: 'flex', gap: 12, alignItems: 'center',
                  justifyContent: 'space-between', flexWrap: 'wrap',
                }}>
                  <span className="mute small">
                    {full ? 'Full — waitlist open' : left + (left === 1 ? ' seat left' : ' seats left')}
                  </span>
                  {e.status === 'postponed' ? (
                    <span className="mute small">Awaiting a new date</span>
                  ) : !session ? (
                    <a className="btn btn-gold" href="/signup"
                      style={{ minHeight: 40, padding: '0 16px', fontSize: 14 }}>Join to RSVP</a>
                  ) : session && (e.host_id === session.user.id || e.created_by === session.user.id) ? (
                    <div className="row" style={{ gap: 8 }}>
                      <span className="pill pill-ok" style={{ fontSize: 11.5 }}>
                        {e.kind === 'talk' ? "You're speaking" : "You're hosting"}
                      </span>
                      <a className="btn btn-out" href={'/events/' + e.id}
                        style={{ minHeight: 36, padding: '0 14px', fontSize: 13.5 }}>Edit</a>
                    </div>
                  ) : locked ? (
                    <span className="mute small">Paid members only</span>
                  ) : (
                    <RsvpButton eventId={e.id} address={address}
                      status={mine?.status ?? null} full={full} />
                  )}
                </div>

                {isAdmin && (
                  <div style={{
                    paddingTop: 12, borderTop: '1px dashed var(--line)', display: 'grid', gap: 8,
                  }}>
                    <span className="mute" style={{ fontSize: 11.5, letterSpacing: '.08em', textTransform: 'uppercase' }}>
                      Admin
                    </span>
                    <EventLifecycle eventId={e.id} title={e.title} status={e.status}
                      startsAt={e.starts_at} seatCount={seatRows.length}
                      canDelete />
                  </div>
                )}
              </div>
            </article>
          );
        })}
        {!rows.length && (
          <div className="surf" style={{
            gridColumn: '1 / -1', padding: 'clamp(28px,5vw,48px)', textAlign: 'center',
          }}>
            <h3 style={{ fontSize: 22 }}>
              {city || kind ? 'No events match that filter' : 'No events yet'}
            </h3>
            <p className="mute" style={{ margin: '10px auto 0', maxWidth: '42ch' }}>
              {city || kind
                ? 'Try a different chapter or type — or propose one yourself.'
                : 'Be the first. Pick a coffee shop, a time, and how many people you want around the table.'}
            </p>
            {session && (
              <a className="btn btn-gold" href="/events/new"
                style={{ marginTop: 18 }}>Propose a meetup</a>
            )}
          </div>
        )}
      </div>
    </main>
  );
}

'use server';

import { eventFull, zonedToUtcIso } from '@/lib/eventTime';
import { revalidatePath } from 'next/cache';
import { createAdminClient } from '@/lib/supabase/server';
import { requireSession } from '@/lib/auth';
import { canRunChapter, canHostTalks, isAdmin } from '@/lib/permissions';

/** Who may change an event: its host, that chapter's lead, or an admin. */
async function assertCanManage(eventId: string) {
  const { profile } = await requireSession();
  const db = createAdminClient();
  const { data: ev } = await db.from('events')
    .select('id,title,description,starts_at,chapter_id,host_id,created_by,status,venue_id,seat_cap,format,meeting_url,meeting_note,original_starts_at,chapters(city)')
    .eq('id', eventId).maybeSingle();
  if (!ev) return { error: 'Event not found' as const };

  const allowed = isAdmin(profile)
    || (canRunChapter(profile) && profile.lead_chapter_id === ev.chapter_id)
    || ev.host_id === profile.id
    || ev.created_by === profile.id;
  if (!allowed) return { error: 'You cannot change this event' as const };

  return { ev, profile, db };
}

/** Times in notifications must read in the chapter's own zone, not the server's. */
function whenText(iso: string, city?: string | null) {
  return eventFull(iso, city);
}

/** Move an event to a new date, telling everyone who holds a seat. */
export async function rescheduleEvent(formData: FormData) {
  const eventId = String(formData.get('event_id') ?? '');
  const newStart = String(formData.get('starts_at') ?? '');
  const note = String(formData.get('note') ?? '').slice(0, 500);
  if (!newStart) return { error: 'Pick a new date and time.' };

  const ctx = await assertCanManage(eventId);
  if ('error' in ctx) return ctx;
  const { ev, profile, db } = ctx;

  const iso = zonedToUtcIso(newStart, ev.chapters?.city);

  const { error } = await db.from('events').update({
    starts_at: iso,
    original_starts_at: ev.original_starts_at ?? ev.starts_at,
    status: 'published',
    status_note: note || null,
    status_changed_at: new Date().toISOString(),
    status_changed_by: profile.id,
  }).eq('id', eventId);
  if (error) return { error: error.message };

  await db.from('event_changes').insert({
    event_id: eventId, kind: 'rescheduled',
    from_starts_at: ev.starts_at, to_starts_at: iso,
    note: note || null, actor_id: profile.id,
  });

  await db.rpc('notify_event_attendees', {
    ev_id: eventId,
    n_kind: 'event.rescheduled',
    n_title: ev.title + ' has moved',
    n_body: 'Now ' + whenText(iso, ev.chapters?.city) + (note ? ' — ' + note : '') + '. Your seat carries over.',
    actor: profile.id,
  });

  revalidatePath('/events');
  revalidatePath('/chapter');
  revalidatePath('/speaker');
  revalidatePath('/admin');
  return { ok: 'Moved, and everyone holding a seat has been told.' };
}

/** Take an event off the calendar without losing its seats. */
export async function postponeEvent(formData: FormData) {
  const eventId = String(formData.get('event_id') ?? '');
  const note = String(formData.get('note') ?? '').slice(0, 500);

  const ctx = await assertCanManage(eventId);
  if ('error' in ctx) return ctx;
  const { ev, profile, db } = ctx;

  const { error } = await db.from('events').update({
    status: 'postponed',
    original_starts_at: ev.original_starts_at ?? ev.starts_at,
    status_note: note || null,
    status_changed_at: new Date().toISOString(),
    status_changed_by: profile.id,
  }).eq('id', eventId);
  if (error) return { error: error.message };

  await db.from('event_changes').insert({
    event_id: eventId, kind: 'postponed',
    from_starts_at: ev.starts_at, note: note || null, actor_id: profile.id,
  });

  await db.rpc('notify_event_attendees', {
    ev_id: eventId,
    n_kind: 'event.postponed',
    n_title: ev.title + ' is postponed',
    n_body: (note || 'A new date will be announced.') + ' Your seat is held.',
    actor: profile.id,
  });

  revalidatePath('/events');
  revalidatePath('/chapter');
  revalidatePath('/speaker');
  return { ok: 'Postponed. Seats are held and everyone has been told.' };
}

export async function cancelEvent(formData: FormData) {
  const eventId = String(formData.get('event_id') ?? '');
  const note = String(formData.get('note') ?? '').slice(0, 500);

  const ctx = await assertCanManage(eventId);
  if ('error' in ctx) return ctx;
  const { ev, profile, db } = ctx;

  await db.rpc('notify_event_attendees', {
    ev_id: eventId,
    n_kind: 'event.cancelled',
    n_title: ev.title + ' is cancelled',
    n_body: note || 'Sorry — this one is off. Your seat has been released.',
    actor: profile.id,
  });

  const { error } = await db.from('events').update({
    status: 'cancelled',
    status_note: note || null,
    status_changed_at: new Date().toISOString(),
    status_changed_by: profile.id,
  }).eq('id', eventId);
  if (error) return { error: error.message };

  await db.from('event_seats').update({ status: 'cancelled' }).eq('event_id', eventId);

  await db.from('event_changes').insert({
    event_id: eventId, kind: 'cancelled',
    from_starts_at: ev.starts_at, note: note || null, actor_id: profile.id,
  });

  revalidatePath('/events');
  revalidatePath('/chapter');
  revalidatePath('/speaker');
  return { ok: 'Cancelled, and everyone has been told.' };
}

/** Bring a postponed or cancelled event back, on a new date. */
export async function restoreEvent(formData: FormData) {
  const eventId = String(formData.get('event_id') ?? '');
  const newStart = String(formData.get('starts_at') ?? '');
  if (!newStart) return { error: 'Pick the new date and time.' };

  const ctx = await assertCanManage(eventId);
  if ('error' in ctx) return ctx;
  const { ev, profile, db } = ctx;

  const iso = zonedToUtcIso(newStart, ev.chapters?.city);
  const moved = new Date(iso).getTime() !== new Date(ev.starts_at).getTime();

  const { error } = await db.from('events').update({
    status: 'published', starts_at: iso,
    status_note: 'Back on' + (moved ? ' \u2014 new date confirmed' : ''),
    status_changed_at: new Date().toISOString(), status_changed_by: profile.id,
  }).eq('id', eventId);
  if (error) return { error: error.message };

  await db.from('event_changes').insert({
    event_id: eventId, kind: 'restored',
    from_starts_at: ev.starts_at, to_starts_at: iso, actor_id: profile.id,
  });

  await db.rpc('notify_event_attendees', {
    ev_id: eventId,
    n_kind: 'event.restored',
    n_title: 'Good news \u2014 ' + ev.title + ' is back on',
    n_body: (moved ? 'New date: ' : 'Still ') + whenText(iso, ev.chapters?.city)
      + '. Your seat was held the whole time, so there is nothing to do but turn up.',
    actor: profile.id,
  });

  // everyone else in the chapter gets told it is open again
  await db.from('notifications').insert(
    ((await db.from('profiles').select('id')
      .eq('chapter_id', ev.chapter_id).neq('id', profile.id)).data ?? [])
      .map((p: any) => ({
        profile_id: p.id,
        kind: 'event.restored',
        title: ev.title + ' is back on the calendar',
        body: whenText(iso, ev.chapters?.city) + '. Seats are open again.',
        href: '/events/' + eventId,
        actor_id: profile.id,
      })),
  );

  revalidatePath('/events');
  revalidatePath('/chapter');
  revalidatePath('/dashboard');
  return {
    ok: moved
      ? 'Back on for ' + whenText(iso, ev.chapters?.city) + '. Seat holders and the chapter have been told.'
      : 'Back on. Seat holders and the chapter have been told.',
  };
}

/**
 * Permanently remove an event. Admins only — Chapter Leads cancel instead,
 * so the record and its history survive.
 */
export async function deleteEvent(formData: FormData) {
  const { profile } = await requireSession();
  if (!isAdmin(profile)) return { error: 'Admins only. Cancel it instead to keep the record.' };

  const eventId = String(formData.get('event_id') ?? '');
  const note = String(formData.get('note') ?? '').slice(0, 500);
  const db = createAdminClient();

  const { data: ev } = await db.from('events')
    .select('id,title,starts_at').eq('id', eventId).maybeSingle();
  if (!ev) return { error: 'Event not found' };

  // tell people before the seats disappear
  await db.rpc('notify_event_attendees', {
    ev_id: eventId,
    n_kind: 'event.cancelled',
    n_title: ev.title + ' has been removed',
    n_body: note || 'This event is no longer going ahead. Your seat has been released.',
    actor: profile.id,
  });

  await db.from('audit_log').insert({
    actor_id: profile.id, action: 'event.delete', target: eventId,
    meta: { title: ev.title, starts_at: ev.starts_at, note: note || null },
  });

  // seats, changes and reports cascade with the event row
  const { error } = await db.from('events').delete().eq('id', eventId);
  if (error) return { error: 'Delete failed: ' + error.message };

  revalidatePath('/events');
  revalidatePath('/chapter');
  revalidatePath('/speaker');
  revalidatePath('/admin');
  revalidatePath('/dashboard');
  return { ok: 'Event deleted, and everyone holding a seat has been told.' };
}

/**
 * Edit an event's details. Open to whoever scheduled it, its host, that
 * chapter's lead, or an admin.
 *
 * Changing the date here goes through the same path as a reschedule, so seat
 * holders are told rather than quietly moved. Everything else — title, blurb,
 * seats, venue, meeting link — is a silent correction, since nobody needs a
 * notification about a fixed typo.
 */
export async function editEvent(formData: FormData) {
  const eventId = String(formData.get('event_id') ?? '');
  const ctx = await assertCanManage(eventId);
  if ('error' in ctx) return ctx;
  const { ev, profile, db } = ctx;

  const title = String(formData.get('title') ?? '').trim().slice(0, 200);
  if (!title) return { error: 'An event needs a title.' };

  const startsAt = String(formData.get('starts_at') ?? '');
  const iso = startsAt ? zonedToUtcIso(startsAt, ev.chapters?.city) : ev.starts_at;
  const moved = new Date(iso).getTime() !== new Date(ev.starts_at).getTime();

  const format = String(formData.get('format') ?? ev.format ?? 'in_person') === 'online'
    ? 'online' : 'in_person';
  const meetingUrl = String(formData.get('meeting_url') ?? '').trim();
  if (format === 'online' && !/^https?:\/\//i.test(meetingUrl)) {
    return { error: 'Online events need a meeting link starting with https://' };
  }

  const ceiling = format === 'online' ? 100 : 15;
  const rawSeats = Number(formData.get('seat_cap') ?? ev.seat_cap);
  const seatCap = Math.min(ceiling, Math.max(2, Number.isFinite(rawSeats) ? rawSeats : ev.seat_cap));

  // never strand people already holding a seat
  const { count: takenCount } = await db.from('event_seats')
    .select('id', { count: 'exact', head: true })
    .eq('event_id', eventId).eq('status', 'confirmed');
  if ((takenCount ?? 0) > seatCap) {
    return { error: (takenCount ?? 0) + ' people are already confirmed. Set seats to at least that.' };
  }

  const patch: Record<string, unknown> = {
    title,
    description: String(formData.get('description') ?? '').slice(0, 4000) || null,
    seat_cap: seatCap,
    format,
    meeting_url: format === 'online' ? meetingUrl : null,
    meeting_note: format === 'online'
      ? String(formData.get('meeting_note') ?? '').slice(0, 300) || null
      : null,
    venue_id: format === 'online'
      ? null
      : (String(formData.get('venue_id') || '') || ev.venue_id),
  };

  if (moved) {
    patch.starts_at = iso;
    patch.original_starts_at = ev.original_starts_at ?? ev.starts_at;
    patch.status_changed_at = new Date().toISOString();
    patch.status_changed_by = profile.id;
  }

  const { error } = await db.from('events').update(patch).eq('id', eventId);
  if (error) return { error: error.message };

  if (moved) {
    await db.from('event_changes').insert({
      event_id: eventId, kind: 'rescheduled',
      from_starts_at: ev.starts_at, to_starts_at: iso, actor_id: profile.id,
    });
    await db.rpc('notify_event_attendees', {
      ev_id: eventId,
      n_kind: 'event.rescheduled',
      n_title: title + ' has moved',
      n_body: 'Now ' + whenText(iso, ev.chapters?.city) + '. Your seat carries over.',
      actor: profile.id,
    });
  }

  revalidatePath('/events');
  revalidatePath('/events/' + eventId);
  revalidatePath('/chapter');
  revalidatePath('/speaker');
  revalidatePath('/dashboard');

  return {
    ok: moved
      ? 'Saved, and seat holders have been told about the new time.'
      : 'Saved.',
  };
}

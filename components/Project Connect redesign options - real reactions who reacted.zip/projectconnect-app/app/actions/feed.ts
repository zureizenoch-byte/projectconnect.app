'use server';

import { revalidatePath } from 'next/cache';
import { createClient, createAdminClient } from '@/lib/supabase/server';
import { requireSession } from '@/lib/auth';
import { REACTION_KEYS } from '@/lib/reactions';
import { guardPostInteraction } from '@/lib/blocks';

const IMAGE_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
const MAX_IMAGE_BYTES = 8_000_000;

export async function createPost(formData: FormData) {
  const { user, profile } = await requireSession();
  const body = String(formData.get('body') ?? '').trim();
  const photo = formData.get('photo') as File | null;
  const hasPhoto = !!photo && photo.size > 0;

  // a photograph can carry a post on its own
  if (!body && !hasPhoto) return { error: 'Write something, or add a photo.' };

  let imageUrl: string | null = null;

  if (hasPhoto) {
    if (!IMAGE_TYPES.includes(photo!.type)) {
      return { error: 'Photos must be a JPEG, PNG, WebP or GIF.' };
    }
    if (photo!.size > MAX_IMAGE_BYTES) {
      return { error: 'Photos must be under 8MB.' };
    }

    const ext = (photo!.name.split('.').pop() ?? 'jpg').toLowerCase().slice(0, 5);
    const path = user.id + '/' + Date.now() + '.' + ext;

    // service role, so a storage policy gap cannot silently drop the upload
    const admin = createAdminClient();
    const { error: uploadError } = await admin.storage
      .from('post-images')
      .upload(path, photo!, {
        upsert: false,
        contentType: photo!.type,
        cacheControl: '31536000',
      });

    if (uploadError) {
      return {
        error: uploadError.message.toLowerCase().includes('not found')
          ? 'Photo storage is not set up yet — create a public "post-images" bucket.'
          : 'Could not upload that photo: ' + uploadError.message,
      };
    }

    const { data } = admin.storage.from('post-images').getPublicUrl(path);
    imageUrl = data.publicUrl;
  }

  const supabase = createClient();
  const { error } = await supabase.from('posts').insert({
    chapter_id: profile.chapter_id,
    author_id: user.id,
    body: body.slice(0, 4000),
    image_url: imageUrl,
  });
  if (error) return { error: error.message };

  revalidatePath('/dashboard');
  return { ok: true };
}

/**
 * Feed posts are report-only — no pre-moderation, so a report has to reach
 * someone. Every admin is notified, with the reason and a jump to the queue.
 *
 * Reporting twice is not an error worth showing: the unique constraint means
 * the second attempt is a no-op, and the member has already done their part.
 */
export async function reportPost(postId: string, reason: string) {
  const { user, profile } = await requireSession();

  const blocked = await guardPostInteraction(user.id, postId);
  if (blocked) return blocked;

  const supabase = createClient();
  const { error } = await supabase.from('post_reports')
    .insert({ post_id: postId, reporter_id: user.id, reason: reason.slice(0, 500) });

  if (error) {
    if (error.code === '23505' || error.message.toLowerCase().includes('duplicate')) {
      return { ok: true, already: true };
    }
    return { error: error.message };
  }

  // Tell the admins. Failing to notify must not lose the report itself.
  try {
    const db = createAdminClient();

    const [{ data: admins }, { data: post }] = await Promise.all([
      db.from('profiles').select('id').eq('role', 'admin'),
      db.from('posts').select('body,author_id').eq('id', postId).maybeSingle(),
    ]);

    if (admins?.length) {
      const { data: author } = post?.author_id
        ? await db.from('profiles').select('full_name').eq('id', post.author_id).maybeSingle()
        : { data: null };

      const excerpt = (post?.body ?? '').trim().replace(/\s+/g, ' ').slice(0, 90);
      const who = author?.full_name ?? 'a member';
      const trimmed = reason.trim().slice(0, 140);

      await db.from('notifications').insert(
        admins.map((a: { id: string }) => ({
          profile_id: a.id,
          kind: 'report.post',
          title: 'A post was reported',
          body: who + "'s post"
            + (excerpt ? ' — "' + excerpt + (excerpt.length === 90 ? '…' : '') + '"' : '')
            + (trimmed ? '\nReason: ' + trimmed : '')
            + '\nReported by ' + (profile.full_name ?? 'a member') + '.',
          href: '/admin#reports',
          actor_id: user.id,
        })),
      );
    }
  } catch {
    // the report is filed; the queue will show it either way
  }

  revalidatePath('/admin');
  return { ok: true };
}

export async function deletePost(postId: string) {
  const { user, profile } = await requireSession();
  const supabase = createClient();
  const query = supabase.from('posts').delete().eq('id', postId);
  const { error } = profile.role === 'admin' ? await query : await query.eq('author_id', user.id);
  if (error) return { error: error.message };
  revalidatePath('/dashboard');
  return { ok: true };
}

export async function toggleLike(postId: string) {
  const { user } = await requireSession();

  const blocked = await guardPostInteraction(user.id, postId);
  if (blocked) return blocked;

  const supabase = createClient();
  const { data: existing } = await supabase.from('post_likes')
    .select('post_id').eq('post_id', postId).eq('profile_id', user.id).maybeSingle();

  const { error } = existing
    ? await supabase.from('post_likes').delete().eq('post_id', postId).eq('profile_id', user.id)
    : await supabase.from('post_likes').insert({ post_id: postId, profile_id: user.id });
  if (error) return { error: error.message };
  return { ok: true, liked: !existing };
}

export async function addComment(postId: string, body: string) {
  const { user, profile } = await requireSession();
  const text = body.trim();
  if (!text) return { error: 'Write something first' };

  const blocked = await guardPostInteraction(user.id, postId);
  if (blocked) return blocked;

  const supabase = createClient();
  const { data, error } = await supabase.from('post_comments')
    .insert({ post_id: postId, author_id: user.id, body: text.slice(0, 2000) })
    .select('id,body,created_at,author_id').single();
  if (error) return { error: error.message };
  revalidatePath('/dashboard');
  return {
    ok: true,
    comment: { ...data, commenter: { full_name: profile.full_name, photo_url: profile.photo_url } },
  };
}

export async function deleteComment(commentId: string) {
  const { user, profile } = await requireSession();
  const supabase = createClient();
  const q = supabase.from('post_comments').delete().eq('id', commentId);
  const { error } = profile.role === 'admin' ? await q : await q.eq('author_id', user.id);
  if (error) return { error: error.message };
  revalidatePath('/dashboard');
  return { ok: true };
}

/**
 * Set, change or clear your reaction to a post.
 *
 * One reaction per person: choosing a different one replaces it, choosing the
 * same one again clears it. That is the behaviour people already know, and it
 * keeps the tally honest without a second table.
 */
export async function setReaction(postId: string, reaction: string) {
  const { user } = await requireSession();
  if (!REACTION_KEYS.includes(reaction)) return { error: 'Unknown reaction.' };

  const blocked = await guardPostInteraction(user.id, postId);
  if (blocked) return blocked;

  const db = createAdminClient();

  const { data: mine } = await db.from('post_likes')
    .select('reaction').eq('post_id', postId).eq('profile_id', user.id).maybeSingle();

  if (mine?.reaction === reaction) {
    const { error } = await db.from('post_likes')
      .delete().eq('post_id', postId).eq('profile_id', user.id);
    if (error) return { error: error.message };
    revalidatePath('/dashboard');
    return { ok: true, reaction: null as string | null };
  }

  const { error } = await db.from('post_likes')
    .upsert({ post_id: postId, profile_id: user.id, reaction },
      { onConflict: 'post_id,profile_id' });
  if (error) return { error: error.message };

  revalidatePath('/dashboard');
  return { ok: true, reaction };
}
